#pragma once
//-------------------------------------------------------------------------------
///
/// \file       xmlload.h 
/// \author     Nathan Morrical
/// \version    1.0
/// \date       August 23, 2017
///
/// \brief Declarations for xmlload.cpp
///
//-------------------------------------------------------------------------------/

